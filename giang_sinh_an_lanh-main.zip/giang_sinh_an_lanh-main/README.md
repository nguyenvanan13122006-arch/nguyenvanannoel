# giang_sinh_an_lanh
Mở bằng VS Code, Git trể tránh bị mất ảnh
